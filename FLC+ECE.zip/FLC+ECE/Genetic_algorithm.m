clc;
clear;
close all;
rng default;

global initial_flag
initial_flag = 0;

% Define problem parameters
func_num = 11;        % CEC function number
dimension = 10;      % Dimension D
num_iterations = 15; % Number of GA runs

% GA options
options = optimoptions('ga', ...
    'PlotFcn', {@gaplotbestf, @gaplotdistance});

% Initialize result containers
ga_main_val = zeros(1, num_iterations);
ga_main_exit_flag = zeros(1, num_iterations);
ga_main_op = cell(1, num_iterations); % cell array since ga_op is a struct

% Run GA multiple times
for i = 1:num_iterations
    initial_flag = 0;

    % Define fitness function handle for the selected CEC function
    fitnessFcn = @(x) benchmark_func(x, func_num);

    % Run GA
    [ga_x, ga_val, ga_exit_flag, ga_op] = ga(fitnessFcn, dimension, options);

    % Store results
    ga_main_val(i) = ga_val;
    ga_main_exit_flag(i) = ga_exit_flag;
    ga_main_op{i} = ga_op;

    % Save visualization
    savefig(sprintf('result(%d).fig', i));
end

% Compute summary statistics
ga_val_max = max(ga_main_val);
ga_val_min = min(ga_main_val);
ga_val_mean = mean(ga_main_val);
ga_val_std = std(ga_main_val);

% Display results
fprintf('GA Value Max: %g\n', ga_val_max);
fprintf('GA Value Min: %g\n', ga_val_min);
fprintf('GA Value Mean: %g\n', ga_val_mean);
fprintf('GA Value Std Dev: %g\n', ga_val_std);
