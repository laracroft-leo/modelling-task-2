clc;
clear;
close all;

global initial_flag
initial_flag = 0;

% Set PSO parameters
func_num = 11;             % CEC function number
dimension = 10;           % Problem dimension
num_iterations = 15;      % Number of runs
lb = -100 * ones(1, dimension);  % Lower bound
ub = 100 * ones(1, dimension);   % Upper bound

% PSO options
options = optimoptions('particleswarm', ...
    'PlotFcn', {@pswplotbestf});

% Initialize result containers
sp_main_x = zeros(num_iterations, dimension);
sp_main_val = zeros(1, num_iterations);
sp_main_exit_flag = zeros(1, num_iterations);
sp_main_op = cell(1, num_iterations);  % Use cell array for output struct

% Run PSO multiple times
for i = 1:num_iterations
    initial_flag = 0;

    % Define fitness function
    fitnessFcn = @(x) benchmark_func(x, func_num);

    % Run PSO
    [sp_x, sp_val, sp_exit_flag, sp_op] = particleswarm(fitnessFcn, dimension, lb, ub, options);

    % Store results
    sp_main_x(i, :) = sp_x;
    sp_main_val(i) = sp_val;
    sp_main_exit_flag(i) = sp_exit_flag;
    sp_main_op{i} = sp_op;

    % Save visualization
    savefig(sprintf('result(%d).fig', i));
end

% Summary statistics
sp_val_max = max(sp_main_val);
sp_val_min = min(sp_main_val);
sp_val_mean = mean(sp_main_val);
sp_val_std = std(sp_main_val);

% Display results
fprintf('PSO Value Max: %g\n', sp_val_max);
fprintf('PSO Value Min: %g\n', sp_val_min);
fprintf('PSO Value Mean: %g\n', sp_val_mean);
fprintf('PSO Value Std Dev: %g\n', sp_val_std);
