function f = fitness_integrate(x)
y = Myfitness(x);  % Invoking a multi-objective function
weights = [0.2, 0.2, 0.2, 0.2, 0.2];  % The weights can be adjusted according to the specific problem or requirements
f = sum(weights .* y);
end
